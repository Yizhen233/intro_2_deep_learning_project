"""SegmentationNN"""
import torch
import torch.nn as nn
import pytorch_lightning as pl
import torchvision.models as models
import torch.nn.functional as F

class SegmentationNN(pl.LightningModule):

    def __init__(self, num_classes=23, hparams=None):
        super().__init__()
        self.hparams = hparams
        #######################################################################
        #                             YOUR CODE                               #
        #######################################################################

        pass
        #self.model = models.alexnet(pretrained=True).features
        
        self.model = models.alexnet(pretrained=True).features
        self.fc1=nn.Linear(9216, 207)
        #self.fc2=nn.Linear(207, 92)
        

        #######################################################################
        #                           END OF YOUR CODE                          #
        #######################################################################

    def forward(self, x):
        """
        Forward pass of the convolutional neural network. Should not be called
        manually but by calling a model instance directly.

        Inputs:
        - x: PyTorch input Variable
        """
        #######################################################################
        #                             YOUR CODE                               #
        #######################################################################

        pass
        #x=self.model(x)
        #m=nn.Conv2d(256,23,1)
        #x=m(x)
        
        x=self.model(x)
        x = x.view(x.size(0),-1)
        
        x=self.fc1(x)
        #x=self.fc2(x)
        x = x.view(x.size(0),23,3,-1)
        
        m=nn.Upsample(size=(240,240))
        x=m(x)
        #print(x.size())
        
       

        #######################################################################
        #                           END OF YOUR CODE                          #
        #######################################################################

        return x
    ########################################################################################################
    
    def general_step(self, batch, batch_idx, mode):
        images, targets = batch
        

        # forward pass
        out = self.forward(images)
        

        # loss
        loss_func = torch.nn.CrossEntropyLoss(ignore_index=-1, reduction='mean')
        loss=loss_func(out, targets)

        return loss,out
    
    def general_end(self, outputs, mode):
        # average over all batches aggregated during one epoch
        avg_loss = torch.stack([x[mode + '_loss'] for x in outputs]).mean()
        return avg_loss

    def training_step(self, batch, batch_idx):
        loss, n_correct = self.general_step(batch, batch_idx, "train")
        tensorboard_logs = {'loss': loss}
        
        return {'loss': loss, 'train_n_correct': n_correct, 'log': tensorboard_logs}

    def validation_step(self, batch, batch_idx):
        loss, n_correct = self.general_step(batch, batch_idx, "val")

        return loss
    def test_step(self, batch, batch_idx):
        loss, n_correct = self.general_step(batch, batch_idx, "test")
        return {'test_loss': loss, 'test_n_correct':n_correct}

    #def validation_end(self, outputs):
        #avg_loss,acc = self.general_end(outputs, "val")
        #tensorboard_logs = {'val_loss': avg_loss}
        #return {'val_loss': avg_loss, 'val_acc': acc, 'log': tensorboard_logs}

    def configure_optimizers(self):

        optim = None
        params = list(self.fc1.parameters()) + list(self.model.parameters())
        optim = torch.optim.Adam(params,1e-3)
        #optim = torch.optim.Adam(self.model.parameters(),self.hparams["learning_rate"])
        return optim
    ########################################################################################################
    

    @property
    def is_cuda(self):
        """
        Check if model parameters are allocated on the GPU.
        """
        return next(self.parameters()).is_cuda

    def save(self, path):
        """
        Save model with its parameters to the given path. Conventionally the
        path should end with "*.model".

        Inputs:
        - path: path string
        """
        print('Saving model... %s' % path)
        torch.save(self, path)

        
class DummySegmentationModel(pl.LightningModule):

    def __init__(self, target_image):
        super().__init__()
        def _to_one_hot(y, num_classes):
            scatter_dim = len(y.size())
            y_tensor = y.view(*y.size(), -1)
            zeros = torch.zeros(*y.size(), num_classes, dtype=y.dtype)

            return zeros.scatter(scatter_dim, y_tensor, 1)

        target_image[target_image == -1] = 1

        self.prediction = _to_one_hot(target_image, 23).permute(2, 0, 1).unsqueeze(0)

    def forward(self, x):
        return self.prediction.float()
